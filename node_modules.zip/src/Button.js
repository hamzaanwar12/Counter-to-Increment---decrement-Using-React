import "./Button.css"

const Button = (props) => {
    
    return (
        <h1>Button 1</h1>
        // <h1 className="card" onClick = {props.click}>
        // {props.purpose}
        //     {/* <span className="top"></span>
        //     <span className="right"></span>
        //     <span className="bottom"></span>
        //     <span className="left" ></span> */}
        // </h1>
    );
}

export default Button